<!-- Generated from content/docs/components/form-section.mdx. Do not edit. -->

# Form Section

Heading plus FormSectionGroup and FormSectionItem.

## Example

```tsx
import { ExternalLinkRegular } from '@mingcute/react/core-regular'
import { Button } from '@ui/actions/button'
import { Badge } from '@ui/displaying-data/badge'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@ui/form/field'
import { Input } from '@ui/form/input'
import { FormSection, FormSectionGroup, FormSectionItem } from '@ui/form/form-section'
import { Switch } from '@ui/form/switch'
import { TooltipProvider } from '@ui/overlays/tooltip'

function FormSectionDemo() {
  return (
    <TooltipProvider>
      <>
        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Default
          </p>
          <FormSection
            title="Online Store"
            description="Storefront URL, theme, and password protection."
          />
        </div>

        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Badge and action
          </p>
          <FormSection
            title="Payment Channels"
            description="Upgrade to accept GrabPay, PayNow, and cards at checkout."
            badge={<Badge tone="purple">Upgrade</Badge>}
            actions={<Button>Upgrade Now</Button>}
          />
        </div>

        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Notification
          </p>
          <FormSection
            title="Invoices"
            description="Overdue invoices that need a reminder."
            notification={2}
            hint="Unread items that need a response."
          />
        </div>

        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Button group
          </p>
          <FormSection
            title="Online Store theme"
            description="Preview changes before they go live."
            actions={
              <>
                <Button variant="secondary" size="sm">
                  Preview
                  <ExternalLinkRegular />
                </Button>
                <Button size="sm">
                  Save
                </Button>
              </>
            }
          />
        </div>

        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Recurring
          </p>
          <FormSection
            title="Recurring"
            description="Monthly membership billed to saved payment methods."
            badge={<Badge tone="blue">Active</Badge>}
          />
        </div>

        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            POS
          </p>
          <FormSection
            title="Point of Sale"
            description="Terminals, receipts, and in-store payment channels."
            actions={
              <Button variant="secondary" size="sm">
                Manage terminals
              </Button>
            }
          />
        </div>

        <div className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            With form
          </p>
          <FormSectionGroup className="max-w-xl">
            <FormSection
              title="Online Store"
              description="These fields share the same left edge as the section title."
            />
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="store-name">Store name</FieldLabel>
                <Input id="store-name" placeholder="HitPay Studio" />
                <FieldDescription>Shown on invoices and receipts.</FieldDescription>
              </Field>
              <Field>
                <FieldLabel htmlFor="store-url">Store URL</FieldLabel>
                <Input id="store-url" placeholder="your-store.hitpay.shop" />
              </Field>
              <FormSectionItem
                title="Password protection"
                description="Visitors must enter a password before they can view the store."
                actions={<Switch defaultChecked />}
              >
                <Input placeholder="Enter password" type="password" />
              </FormSectionItem>
              <FormSectionItem
                variant="background"
                title="Guest checkout"
                description="Let customers pay without creating an account."
                actions={<Switch defaultChecked />}
              />
            </FieldGroup>
          </FormSectionGroup>
        </div>
      </>
    </TooltipProvider>
  )
}

export { FormSectionDemo }
```
