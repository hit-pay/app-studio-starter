<!-- Generated from content/docs/components/form-builder.mdx. Do not edit. -->

# Form Builder

Schema-driven create/edit form. Use Detail Card for a read-only record.

## Interactive example

The interactive example is rendered on the Orchid documentation page. Use the usage guidance below and verify the installed component source for the exact API.

Use `FormBuilder` for multi-field create/edit. Use `DetailCard` for a read-only record.
Unknown `type` values throw. Use only the listed FormBuilder types. Render inside `FormLayout`. Do not wrap in `Card`.

## Change callback

`SchemaForm` accepts `onChange?: (values: SchemaFormValues, change: SchemaFormChange) => void`.
It runs once for each user interaction, after constructing the latest nested values snapshot. It
does not run on the initial render or when props rerender.

`change.path` is the primary changed path, `change.paths` contains every path changed by that
interaction, and `change.value` / `change.previousValue` describe the primary value. The
`changedValues` and `previousValues` records contain path-keyed metadata for every changed value,
while `change.field` identifies the related flattened schema field.

Paired controls such as `amount+currency`, `from+to`, and range sliders emit one callback per
interaction. When both values change together, both paths are included in `change.paths`. Custom
`renderField` controls use the same behavior when their `onChange` writes a paired object.

Submission remains external. Configure submission through `useSchemaForm({ onSubmit })`, assign an
`id` to the form, and point an external button at that id:

```tsx
const form = useSchemaForm({ fields, onSubmit: saveValues })

<SchemaForm id="settings-form" form={form} onChange={handleChange} />
<Button type="submit" form="settings-form">Save</Button>
```

## Column layout

`columns` creates a responsive grid: one column on small screens, then the configured number of columns at the appropriate breakpoints. Rules can target fields by name or control type.

```tsx
const fields = [
  {
    key: "product_name",
    title: "Product Name",
    type: "input",
    props: { colSpan: "full" },
  },
  { key: "sku", title: "SKU", type: "input" },
  { key: "barcode", title: "Barcode", type: "input" },
]

<SchemaForm
  form={form}
  layout={{
    columns: 2,
    fields: { product_name: "full" },
    types: { textarea: "full" },
  }}
/>
```

Span priority is `props.colSpan`, `layout.fields`, `layout.types`, then one column. `section` and `section-item` fields always span the full row.

## Choice card

Use `type: "choice-card"` for a single card-style choice. Each option can include a `description`. The stored value is the selected `option.value`.

```tsx
const fields = [
  {
    key: "channel",
    title: "Channel",
    type: "choice-card",
    required: true,
    options: [
      { value: "paynow", label: "PayNow", description: "Instant bank transfer" },
      { value: "card", label: "Card", description: "Visa, Mastercard, AMEX" },
    ],
    value: "paynow",
  },
]
```

`props.alignment` is `Vertical` (default) or `Horizontal`. `props.cardAlignment` is `Left` (default) or `Center`.

## Staff and role

Use `type: "staff"` and `type: "role"` for HitPay app members and business roles. Use `type: "coupon"` / `"discount"` / `"tax"` / `"shipping"` / `"pickup"` / `"product-category"` / `"location"` for those HitPay dropdowns. They render the matching Select. The stored value is `{ id, name }` (or an array when `props.multiple` is true).

```tsx
const fields = [
  { key: "assignee", title: "Assignee", type: "staff", required: true },
  {
    key: "reviewers",
    title: "Reviewers",
    type: "staff",
    props: { multiple: true, roleTitles: ["Manager", "Admin"] },
  },
  { key: "notify_role", title: "Notify role", type: "role" },
]
```

Do not fetch staff or roles on the screen. Optional staff `props`: `multiple`, `roleTitles`, `locationId`.
