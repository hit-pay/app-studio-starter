<!-- Generated from content/docs/components/banner.mdx. Do not edit. -->

# Banner

In-page notification with semantic variants and an optional action.

## Example

```tsx
import {
  CheckCircleRegular,
  InformationRegular,
  AlertRegular,
  CloseCircleRegular,
} from '@mingcute/react/core-regular';

import {
  Banner,
  BannerAction,
  BannerDescription,
  BannerTitle,
} from "@ui/feedback/banner";
import { Button } from "@ui/actions/button";

function BannerDemo() {
  return (
    <>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Default
          </p>
          <Banner>
            <InformationRegular />
            <BannerTitle>PayNow delay</BannerTitle>
            <BannerDescription>
              Payments may take longer than usual. Consider using Cards or
              GrabPay while the channel recovers.
            </BannerDescription>
          </Banner>
        </div>

        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Success
          </p>
          <Banner variant="success">
            <CheckCircleRegular />
            <BannerTitle>Payment received</BannerTitle>
            <BannerDescription>
              SGD 128.00 for INV-2048 was paid successfully through PayNow.
            </BannerDescription>
          </Banner>
        </div>

        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Warning
          </p>
          <Banner variant="warning">
            <AlertRegular />
            <BannerTitle>Low stock</BannerTitle>
            <BannerDescription>
              SKU-TEA-12 has 3 units remaining. Restock before the weekend
              promotion.
            </BannerDescription>
          </Banner>
        </div>

        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Destructive
          </p>
          <Banner variant="destructive">
            <CloseCircleRegular />
            <BannerTitle>Refund failed</BannerTitle>
            <BannerDescription>
              We could not refund SGD 48.00 on INV-2048. Retry or contact the
              customer.
            </BannerDescription>
          </Banner>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Default action
          </p>
          <Banner>
            <InformationRegular />
            <BannerTitle>PayNow delay</BannerTitle>
            <BannerDescription>
              Payments may take longer than usual.
            </BannerDescription>
            <BannerAction>
              <Button variant="outline" size="sm">
                View status
              </Button>
            </BannerAction>
          </Banner>
        </div>

        <div className="space-y-3">
          <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
            Bottom action
          </p>
          <Banner variant="success">
            <CheckCircleRegular />
            <BannerTitle>Invoice created</BannerTitle>
            <BannerDescription>
              INV-2048 for SGD 128.00 was created and sent to Priya Nair.
            </BannerDescription>
            <BannerAction placement="bottom">
              <Button variant="outline" size="sm">
                View invoice
              </Button>
              <Button size="sm">Send reminder</Button>
            </BannerAction>
          </Banner>
        </div>
      </div>

      <div className="space-y-4">
        <p className="text-xs font-medium tracking-[0.18em] text-oc-muted-foreground uppercase">
          Above page header
        </p>
        <Banner>
          <InformationRegular />
          <BannerTitle>Scheduled maintenance</BannerTitle>
          <BannerDescription>
            Dashboard reporting may be delayed between 02:00 and 02:30 SGT.
          </BannerDescription>
        </Banner>
        <header className="flex w-full min-w-0 flex-col gap-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
          <div className="min-w-0 flex-1">
            <h2 className="wrap-break-word text-lg leading-6 font-medium text-oc-foreground">
              Invoices
            </h2>
            <p className="wrap-break-word text-sm leading-5 text-oc-muted-foreground">
              Create, send, and track invoices across payment channels.
            </p>
          </div>
          <div className="flex justify-end sm:shrink-0">
            <Button>Create invoice</Button>
          </div>
        </header>
      </div>
    </>
  );
}

export { BannerDemo };
```
