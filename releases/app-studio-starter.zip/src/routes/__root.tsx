import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'

import { QueryProvider } from '#/lib/query'
import { AppLayout } from '@/components/ui/app-layout'
import { ConfirmationModalProvider } from '@/components/ui/confirmation-modal'
import { Page, PageContent } from '@/components/ui/page'
import { Toaster } from '@/components/ui/toast'
import appCss from '../styles.css?url'

function NotFound() {
  return (
    <AppLayout className="h-full">
      <Page>
        <PageContent className="mt-0 flex items-center justify-center">
          <p className="text-sm text-oc-muted-foreground">That page does not exist.</p>
        </PageContent>
      </Page>
    </AppLayout>
  )
}

export const Route = createRootRoute({
  notFoundComponent: NotFound,
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'HitPay App' },
    ],
    links: [
      { rel: 'icon', href: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%232465de"/></svg>' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: '' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
      },
      { rel: 'stylesheet', href: appCss },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <head>
        <HeadContent />
      </head>
      <body className="h-full">
        <QueryProvider>
          <ConfirmationModalProvider>
            <Toaster placement="top-center">{children}</Toaster>
          </ConfirmationModalProvider>
        </QueryProvider>
        <Scripts />
      </body>
    </html>
  )
}
