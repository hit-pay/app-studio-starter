import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'

import { QueryProvider } from '#/lib/query'
import { ConfirmationModalProvider } from '@/components/overlays/confirmation-modal'
import { Toaster } from '@/base-ui/feedback/toast'
import '../styles.css'

function NotFound() {
  return (
    <main className="flex h-full min-h-0 w-full flex-1 items-center justify-center px-6">
      <p className="text-sm text-oc-muted-foreground">That page does not exist.</p>
    </main>
  )
}

function Pending() {
  return (
    <div className="flex h-full min-h-0 w-full flex-1 items-center justify-center">
      <p className="text-sm text-oc-muted-foreground">Loading…</p>
    </div>
  )
}

export const Route = createRootRoute({
  ssr: false,
  pendingComponent: Pending,
  notFoundComponent: NotFound,
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'HitPay App' },
    ],
    links: [
      { rel: 'icon', href: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="%232465de"/></svg>' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: '' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <head>
        <HeadContent />
      </head>
      <body className="h-full">
        <QueryProvider>
          <ConfirmationModalProvider>
            <Toaster placement="top-center">{children}</Toaster>
          </ConfirmationModalProvider>
        </QueryProvider>
        <Scripts />
      </body>
    </html>
  )
}
